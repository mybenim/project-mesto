const initialCards = [
  {
    name: "Оранжевый амфиприон",
    link: "https://images.unsplash.com/photo-1617994318470-917a8ae86336?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
  },
  {
    name: "Аквариум",
    link: "https://images.unsplash.com/photo-1617994679330-2883951d0073?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
  },
  {
    name: "Бычковая мандаринка",
    link: "https://images.unsplash.com/photo-1550016681-60a1d9d23bf7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=3263&q=80"
  },
  {
    name: "Аквариум",
    link: "https://images.unsplash.com/photo-1516970739312-08b075784b71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1176&q=80"
  },
  {
    name: "Монако",
    link: "https://images.unsplash.com/photo-1579437444743-1e186732c075?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
  },
  {
    name: "Морской пейзаж",
    link: "https://images.unsplash.com/photo-1683022559491-a2a9bf989561?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
  }
];



/*function deleteCard(event) {
  const card = event.target.close(".card");
  itemElement.remove();
} */




/*const listCard = document.querySelector(".element__item");
const cardTemplate = document.querySelector("#card-template").content;
const itemElement = cardTemplate.querySelector(".card").cloneNode(true);

  initialCards.forEach((item) => {
  itemElement.querySelector(".card__item-img").src = item.link;
  itemElement.querySelector(".card__title").textContent = item.name;
  itemElement.querySelector(".card__like-icon").img = item.like;
  itemElement.querySelector(".card__basket").img = item.basket;
    listCard.append(itemElement);
 }); */



/*likeElement.forEach(function(like) {
  like.addEventListener("click", function(evt) {
      evt.target.classList.toggle("card__button-like_active");
  });
}); */





/* function handle.... (evt) {
  evt.preventDefault();
  const ... = функция создания карточки ({
    link: //передаем значения инпутов в карточку
    name: //передаем значения инпутов в карточку
  })
  // вставляем новую карточку в начале
  //очищаем форму после добавления
  //закрываем попап
} */






  /* -------------------Ставим лайк--------------------- */

  /*const likeElement = document.querySelectorAll(".card__button-like");

  /*likeElement.addEventListener("click", function (evt) {
  evt.target.classList.toggle("card__button-like");
}); */

 /* likeElement.forEach(function(like) {
  like.addEventListener("click", function(evt) {
      evt.target.classList.toggle("card__button-like");
  });
}); */

